package com.uia.ing.soft.olda.dunamys.ing_software_dunamys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngSoftwareDunamysApplicationTests {

	@Test
	void contextLoads() {
	}

}
