package com.uia.ing.soft.olda.dunamys.ing_software_dunamys.Exceptions;

public class ClientNotFoundException extends RuntimeException {
    public ClientNotFoundException(String message) {
        super(message);
    }

}
