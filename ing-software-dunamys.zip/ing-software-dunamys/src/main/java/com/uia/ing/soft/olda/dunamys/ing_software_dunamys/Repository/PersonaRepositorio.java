package com.uia.ing.soft.olda.dunamys.ing_software_dunamys.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uia.ing.soft.olda.dunamys.ing_software_dunamys.Model.Persona;

public interface PersonaRepositorio extends JpaRepository<Persona, Long>{

}
