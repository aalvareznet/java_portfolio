package com.uia.ing.soft.olda.dunamys.ing_software_dunamys.Security.user;

public enum Role {
    ADMIN,
    USER
}
